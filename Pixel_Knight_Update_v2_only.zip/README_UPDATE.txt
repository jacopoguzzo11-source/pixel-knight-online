PIXEL KNIGHT ONLINE DUEL v2
===========================

AGGIORNAMENTI
-------------
- Movimento WASD corretto:
  W = avanti rispetto a dove guardi
  S = indietro
  A = sinistra
  D = destra
- Collisione tra i due giocatori: non possono attraversarsi.
- Collisioni con alcuni elementi delle mappe.
- Sistema armi rifatto:
  * Spada
  * Lancia
  * Ascia da guerra
  * Arco
  * Scudo separato
- La spada, lancia e ascia NON sparano.
- L'arco usa frecce reali e munizioni.
- Lo scudo costa 120 monete e abilita la parata con click destro.
- Inventario/equipaggiamento corretto: puoi passare tra tutte le armi possedute.
- Hitbox da mischia più affidabili e permissive.
- Numeri del danno in stile shooter/Fortnite sul bersaglio.
- Hit marker e flash rosso sul nemico quando lo colpisci.
- Tre mappe selezionabili dall'host nella lobby privata:
  * Fortezza di Pietra
  * Rovine della Foresta
  * Colosseo delle Ceneri

PER AGGIORNARE IL GIOCO GIÀ PUBBLICATO
--------------------------------------
Nel tuo repository GitHub devi sostituire soprattutto:
1. server.js
2. public/index.html

Puoi anche copiare tutti i file di questa versione nella cartella locale pixel-knight-online.

Poi in GitHub Desktop:
1. Summary: Update game v2
2. Commit to main
3. Push origin

Se Auto-Deploy è attivo su Render, Render aggiorna da solo lo stesso link pubblico.
